feature_extractor module
========================

.. automodule:: feature_extractor
    :members:
    :undoc-members:
    :show-inheritance:
