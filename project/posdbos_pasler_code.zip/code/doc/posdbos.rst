posdbos module
==============

.. automodule:: posdbos
    :members:
    :undoc-members:
    :show-inheritance:
