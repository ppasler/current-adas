emokit package
==============

Submodules
----------

emokit.emotiv module
--------------------

.. automodule:: emokit.emotiv
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: emokit
    :members:
    :undoc-members:
    :show-inheritance:
