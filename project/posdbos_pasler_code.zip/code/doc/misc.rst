misc package
============

Submodules
----------

misc.butterworth_bandpass module
--------------------------------

.. automodule:: misc.butterworth_bandpass
    :members:
    :undoc-members:
    :show-inheritance:

misc.eeg_signal_plotter module
------------------------------

.. automodule:: misc.eeg_signal_plotter
    :members:
    :undoc-members:
    :show-inheritance:

misc.eeg_signal_plotter2 module
-------------------------------

.. automodule:: misc.eeg_signal_plotter2
    :members:
    :undoc-members:
    :show-inheritance:

misc.feature_plotter module
---------------------------

.. automodule:: misc.feature_plotter
    :members:
    :undoc-members:
    :show-inheritance:

misc.fft_sound_example module
-----------------------------

.. automodule:: misc.fft_sound_example
    :members:
    :undoc-members:
    :show-inheritance:

misc.perceptron_example module
------------------------------

.. automodule:: misc.perceptron_example
    :members:
    :undoc-members:
    :show-inheritance:

misc.render module
------------------

.. automodule:: misc.render
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: misc
    :members:
    :undoc-members:
    :show-inheritance:
