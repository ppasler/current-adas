eeg_processor module
====================

.. automodule:: eeg_processor
    :members:
    :undoc-members:
    :show-inheritance:
