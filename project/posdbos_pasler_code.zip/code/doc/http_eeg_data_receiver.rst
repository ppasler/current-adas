http_eeg_data_receiver module
=============================

.. automodule:: http_eeg_data_receiver
    :members:
    :undoc-members:
    :show-inheritance:
