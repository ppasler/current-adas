test package
============

Submodules
----------

test.chain_test module
----------------------

.. automodule:: test.chain_test
    :members:
    :undoc-members:
    :show-inheritance:

test.classificator_test module
------------------------------

.. automodule:: test.classificator_test
    :members:
    :undoc-members:
    :show-inheritance:

test.config_test module
-----------------------

.. automodule:: test.config_test
    :members:
    :undoc-members:
    :show-inheritance:

test.converter_test module
--------------------------

.. automodule:: test.converter_test
    :members:
    :undoc-members:
    :show-inheritance:

test.data_collector_test module
-------------------------------

.. automodule:: test.data_collector_test
    :members:
    :undoc-members:
    :show-inheritance:

test.feature_extractor_test module
----------------------------------

.. automodule:: test.feature_extractor_test
    :members:
    :undoc-members:
    :show-inheritance:

test.signal_window_test module
------------------------------

.. automodule:: test.signal_window_test
    :members:
    :undoc-members:
    :show-inheritance:

test.util_test module
---------------------

.. automodule:: test.util_test
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: test
    :members:
    :undoc-members:
    :show-inheritance:
