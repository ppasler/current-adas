src
===

.. toctree::
   :maxdepth: 4

   classification
   config
   data_collector
   data_processor
   eeg_processor
   emokit
   feature_extractor
   http_eeg_data_provider
   http_eeg_data_receiver
   misc
   output
   posdbos
   statistic
   test
   util
   window
