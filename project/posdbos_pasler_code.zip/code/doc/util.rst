util package
============

Submodules
----------

util.eeg_data_source module
---------------------------

.. automodule:: util.eeg_data_source
    :members:
    :undoc-members:
    :show-inheritance:

util.eeg_table_util module
--------------------------

.. automodule:: util.eeg_table_util
    :members:
    :undoc-members:
    :show-inheritance:

util.eeg_util module
--------------------

.. automodule:: util.eeg_util
    :members:
    :undoc-members:
    :show-inheritance:

util.fft_util module
--------------------

.. automodule:: util.fft_util
    :members:
    :undoc-members:
    :show-inheritance:

util.quality_util module
------------------------

.. automodule:: util.quality_util
    :members:
    :undoc-members:
    :show-inheritance:

util.signal_util module
-----------------------

.. automodule:: util.signal_util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: util
    :members:
    :undoc-members:
    :show-inheritance:
