statistic package
=================

Submodules
----------

statistic.signal_statistic_constants module
-------------------------------------------

.. automodule:: statistic.signal_statistic_constants
    :members:
    :undoc-members:
    :show-inheritance:

statistic.signal_statistic_plotter module
-----------------------------------------

.. automodule:: statistic.signal_statistic_plotter
    :members:
    :undoc-members:
    :show-inheritance:

statistic.signal_statistic_printer module
-----------------------------------------

.. automodule:: statistic.signal_statistic_printer
    :members:
    :undoc-members:
    :show-inheritance:

statistic.signal_statistic_util module
--------------------------------------

.. automodule:: statistic.signal_statistic_util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: statistic
    :members:
    :undoc-members:
    :show-inheritance:
