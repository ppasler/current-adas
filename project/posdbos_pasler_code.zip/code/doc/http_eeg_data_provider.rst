http_eeg_data_provider module
=============================

.. automodule:: http_eeg_data_provider
    :members:
    :undoc-members:
    :show-inheritance:
