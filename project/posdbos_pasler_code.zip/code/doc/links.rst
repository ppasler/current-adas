Links
=====

* `Quick reStructuredText <http://docutils.sourceforge.net/docs/user/rst/quickref.html>`_
* `Sphinx for Dummies <https://codeandchaos.wordpress.com/2012/07/30/sphinx-autodoc-tutorial-for-dummies/>`_
* `5 Basics <https://imotions.com/blog/5-basics-eeg-data-processing/>`_
* `Sleep EEG Data Analysis Process <https://www.youtube.com/watch?v=xTnRtF0e9tA>`_


* `Using EEG spectral components to assess algorithms for detecting fatigue <http://www.sciencedirect.com/science/article/pii/S0957417407006914>`_
* `A critical review of the psychophysiology of driver fatigue <http://www.sciencedirect.com/science/article/pii/S0301051100000855>`_

* `Filter <http://stackoverflow.com/questions/13740348/how-to-apply-a-filter-to-a-signal-in-python>`_
* `Filter 2 <http://dsp.stackexchange.com/questions/2864/how-to-write-lowpass-filter-for-sampled-signal-in-python>`_

* ` <>`_